<?php
$productName = "Full Electric Stacker";
$productDescription = "Walkie type electric stacker provides a cost effective solution for applications involving medium lifting storage and short distance pallets transportation.";
$productImage = "../assets/images/products/full-electric-stacker.jpg";
$productDrawing = "../assets/images/products/dimention-drawing/full-electric-stacker.jpg";
include('master.php');
?>
