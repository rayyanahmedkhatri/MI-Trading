
// document.addEventListener('contextmenu', function(event) {
//     event.preventDefault();
// });

// document.addEventListener('keydown', function(event) {
//     // Block Ctrl + Shift + I, Ctrl + Shift + J, Ctrl + U, and F12
//     if (
//         (event.ctrlKey && event.shiftKey && (event.key === 'I' || event.key === 'J')) || 
//         (event.ctrlKey && event.key === 'U') || 
//         event.key === 'F12'
//     ) {
//         event.preventDefault();
//     }
// });

// // Block the context menu in case some browsers trigger the page source shortcut on right-click
// document.addEventListener('keydown', function(event) {
//     // Block Ctrl + U
//     if (event.ctrlKey && event.key === 'U') {
//         event.preventDefault();
//     }
// });
