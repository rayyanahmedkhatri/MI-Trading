<?php
$productName = "Manual Beam Transporter";
$productDescription = "";
$productImage = "../assets/images/products/manual-beam-transporter.jpg";
$productDrawing = "";
include('master.php');
?>