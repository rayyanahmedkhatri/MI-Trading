<?php
$productName = "Electric Pallet Truck";
$productDescription = "● The Mini type with same size as hand pallet truck widely used in narrow aisle workshop, supermarket & cargo containers.";
$productImage = "../assets/images/products/electric-pallet-truck.jpg";
$productDrawing = "../assets/images/products/dimention-drawing/electric-pallet-truck.jpg";
include('master.php');
?>