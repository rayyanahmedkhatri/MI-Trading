<?php
$productName = "Hydraulic Patcher Mover";
$productDescription = "";
$productImage = "../assets/images/products/hydraulic-patcher-mover.jpg";
$productDrawing = "";
include('master.php');
?>