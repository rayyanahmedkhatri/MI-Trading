<?php
$productName = "Hand Pallet Truck";
$productDescription = "Description : N/A";
$productImage = "../assets/images/products/hand-pallet-truck.jpg";
$productDrawing = "../assets/images/products/dimention-drawing/hand-pallet-truck.jpg";
include('master.php');
?>
