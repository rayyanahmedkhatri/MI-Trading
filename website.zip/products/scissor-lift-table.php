<?php
$productName = "Scissor Lift Table";
$productDescription = "";
$productImage = "../assets/images/products/scissor-lift-table.jpg";
$productDrawing = "../assets/images/products/dimention-drawing/scissor-lift-table.jpg";
include('master.php');
?>
