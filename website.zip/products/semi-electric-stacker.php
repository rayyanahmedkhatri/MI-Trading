<?php
$productName = "Semi Electric Stacker";
$productDescription = "";
$productImage = "../assets/images/products/semi-electric-stacker.jpg";
$productDrawing = "../assets/images/products/dimention-drawing/semi-electric-stacker.jpg";
include('master.php');
?>
