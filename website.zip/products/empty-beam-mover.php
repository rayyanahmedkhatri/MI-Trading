<?php
$productName = "Empty Beam Mover";
$productDescription = "";
$productImage = "../assets/images/products/empty-beam-mover.jpg";
$productDrawing = "";
include('master.php');
?>