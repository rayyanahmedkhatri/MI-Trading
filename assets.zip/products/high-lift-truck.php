<?php
$productName = "High Lift Table";
$productDescription = "";
$productImage = "../assets/images/products/high-lift-truck.jpg";
$productDrawing = "../assets/images/products/dimention-drawing/high-lift-truck.jpg";
include('master.php');
?>
