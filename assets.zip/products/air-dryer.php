<?php
$productName = "Air Dryer";
$productDescription = "";
$productImage = "../assets/images/products/air-dryer.png";
$productDrawing = "";
include('master.php');
?>