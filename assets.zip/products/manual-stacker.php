<?php
$productName = "Manual Stacker";
$productDescription = "";
$productImage = "../assets/images/products/manual-stacker.jpg";
$productDrawing = "../assets/images/products/dimention-drawing/manual-stacker.jpg";
include('master.php');
?>
