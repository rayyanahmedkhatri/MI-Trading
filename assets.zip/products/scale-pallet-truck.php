<?php
$productName = "Scale Pallet Truck";
$productDescription = "";
$productImage = "../assets/images/products/scale-pallet-truck.jpg";
$productDrawing = "../assets/images/products/dimention-drawing/scale-pallet-truck.jpg";
include('master.php');
?>
