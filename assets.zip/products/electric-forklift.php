<?php
$productName = "Electric Forklift";
$productDescription = "";
$productImage = "../assets/images/products/forklift/electric-forklift.png";
$productDrawing = "";
include('master.php');
?>