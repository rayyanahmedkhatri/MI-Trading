<?php
$productName = "Screw Air Compressor";
$productDescription = "";
$productImage = "../assets/images/products/screw-air-compressor.png";
$productDrawing = "";
include('master.php');
?>