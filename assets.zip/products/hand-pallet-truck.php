<?php
$productName = "Hand Pallet Truck";
$productDescription = "Premium Type";
$productImage = "../assets/images/products/hand-pallet-truck.jpg";
$productDrawing = "../assets/images/products/dimention-drawing/hand-pallet-truck.jpg";
$advantage = "<ul>
  <li>● Integrated pump without welding, no any leaking problems.</li>
  <li>● Frame force is more reasonable, and the strength is more reliable.</li>
  <li>● Handle seat has hole it is more convenient for installation of control chain.</li>
  <li>● Forks lowering speed is controllable, with overload valve to avoid overloading</li>
  <li>● Option:
    <ul>
      <li>1) Steering wheel 200mm (fork wheel 80mm) are available.</li>
      <li>2) Nylon wheel, polyurethane wheel, rubber wheel, single fork roller or tandem fork rollers.</li>
      <li>3) Fork length: 800mm, 900mm, 1000mm, 1100mm.</li>
      <li>4) Foot pedal release.</li>
      <li>5) Pump color: black painting.</li>
      <li>6) Quick lift (double speed lifting).</li>
    </ul>
  </li>
</ul>";
include('master.php');
?>
