<?php
$productName = "Diesel Forklift";
$productDescription = "";
$productImage = "../assets/images/products/forklift/diesel-forklift.png";
$productDrawing = "";
include('master.php');
?>