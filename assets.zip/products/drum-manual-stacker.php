<?php
$productName = "Drum Manual Stacker";
$productDescription = "";
$productImage = "../assets/images/products/drum-manual-stacker.jpg";
$productDrawing = "../assets/images/products/dimention-drawing/drum-manual-stacker.jpg";
include('master.php');
?>
