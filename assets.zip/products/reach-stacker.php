<?php
$productName = "Reach Stacker";
$productDescription = "";
$productImage = "../assets/images/products/reach-stacker.jpg";
$productDrawing = "../assets/images/products/dimention-drawing/reach-stacker.jpg";
include('master.php');
?>
